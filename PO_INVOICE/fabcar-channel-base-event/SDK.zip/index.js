//var controller = require('../controller/process')
var app = require('express').Router();
const logger = require('../utils/logger');
const toBC = require('../controller/toBC');

function getUser(key) { // for transfer 
  let functionName = '[toBC.ParseCheckUser(unparsedAttrs)]';

  return new Promise((resolve, reject) => {
      
      let getuser = {};
      //new kvs().putStore(inv_identity,unparsedAttrs)
      
      try {
        getuser = {
              USER: key.USER || '',
          }
          resolve([
            getuser.USER.toString(),
          ])
      } catch (e) {
          logger.error(`${functionName} Parsing attributes failed ${e}`);
          reject(`Sorry could not parse attributes: ${e}`);
      }

  });
}
function getBuyer(key) { // for transfer 
  let functionName = '[toBC.getBuyer(unparsedAttrs)]';

  return new Promise((resolve, reject) => {
      
      let getuser = {};
      //new kvs().putStore(inv_identity,unparsedAttrs)
      
      try {
        getuser = {
              BUYER: key.BUYER || '',
          }
          resolve([
            getuser.BUYER.toString(),
          ])
      } catch (e) {
          logger.error(`${functionName} Parsing attributes failed ${e}`);
          reject(`Sorry could not parse attributes: ${e}`);
      }

  });
}
function getSeller(key) { // for transfer 
  let functionName = '[toBC.ParseCreateTransfer(unparsedAttrs)]';

  return new Promise((resolve, reject) => {
      
      let getuser = {};
      //new kvs().putStore(inv_identity,unparsedAttrs)
      
      try {
        getuser = {
              SELLER: key.SELLER || '',
          }
          resolve([
            getuser.SELLER.toString(),
          ])
      } catch (e) {
          logger.error(`${functionName} Parsing attributes failed ${e}`);
          reject(`Sorry could not parse attributes: ${e}`);
      }

  });
}
app.post('/CreatePO', function (req, res, next) {
  let functionName = '[API: POST /api/v1/CreatePO]';
  getBuyer(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).CreatePO(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to transfer new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to transfer new Service Request: ${error}`
    });
  });
})
  
});

app.post('/CreateInvoice', function (req, res, next) {
  let functionName = '[API: POST /api/v1/CreateInvoice]';
  getSeller(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).CreateInvoice(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to transfer new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to transfer new Service Request: ${error}`
    });
  });
})
  
});

app.post('/Borrow_Invoice_Seller', function (req, res, next) {
  let functionName = '[API: POST /api/v1/Borrow_Invoice_Seller]';
  console.log("**********55555555****************")
  getSeller(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).Borrow_Invoice_Seller(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to transfer new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to transfer new Service Request: ${error}`
    });
  });
})
  
});
app.post('/Borrow_Invoice_Buyer', function (req, res, next) {
  let functionName = '[API: POST /api/v1/Borrow_Invoice_Buyer]';
  console.log("**********66666666****************")
  getBuyer(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).Borrow_Invoice_Buyer(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to transfer new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to transfer new Service Request: ${error}`
    });
  });
})
  
});
app.post('/CheckPO', function (req, res, next) {
  let functionName = '[API: POST /api/v1/CheckPO]';

  getBuyer(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).CheckPO(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to check new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to check new Service Request: ${error}`
    });
  });
})
  
}); 
app.post('/CheckInvoice', function (req, res, next) {
  let functionName = '[API: POST /api/v1/CheckInvoice]';

  getSeller(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).CheckInvoice(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to check new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to check new Service Request: ${error}`
    });
  });
})
  
}); 
app.post('/BorrowPO', function (req, res, next) {
  let functionName = '[API: POST /api/v1/BorrowPO]';

  getSeller(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).BorrowPO(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to check new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to check new Service Request: ${error}`
    });
  });
})
  
}); 

app.post('/CheckUser', function (req, res, next) {
  let functionName = '[API: POST /api/v1/CheckUser]';

  getUser(req.body).then((getkey) => {
    const bcuserName = `${getkey}`
new toBC(bcuserName).CheckUser(req.body).then((result) => {
    res.status(201);
    res.json(result.message);
  })
  .catch((error) => {
    logger.error(`${functionName} Failed to check new Service Request: ${error}`);
    res.status(500);
    res.json({
      code: 500,
      message: `Failed to check new Service Request: ${error}`
    });
  });
})
  
}); 

module.exports = app;