const logger = require('../utils/logger');
const blockchain = require('../blockchain/service');
//const UUID = require('../../utils/UUID');

//Chaincode functions names
const CreatePO = 'createPO'; //func
const CHECKPO = 'CHECKPO'; //func
const CHECKINVOICE = 'CHECKINVOICE'; //func
const CreateInvoice = 'createInvoice'; //func
const CheckUser = 'CheckUser'; //func
const INVOKE_ATTRIBUTES = ['devorgId']; //base


var fs = require('fs');
var file = __dirname + '/config.json';
/**
 * Parsing parameters from the object received
 * from client and using default values
 * where needed/possible
 * @function
 * @param {object} unparsedAttrs - New ServiceRequest Object

 */
function ParseCreatePO(unparsedAttrs) { // for transfer 
    let functionName = '[toBC.CreatePO(unparsedAttrs)]';

    return new Promise((resolve, reject) => {
        
        let parsedAttrs = {};
        //new kvs().putStore(inv_identity,unparsedAttrs)
        
        try {
            parsedAttrs = {
                PO_ID: unparsedAttrs.PO_ID || '',
                Buyer : unparsedAttrs.Buyer || '',
                Product: unparsedAttrs.Product || '',
                Num_Product: unparsedAttrs.Num_Product || '',
                Price: unparsedAttrs.Price || '',
                Date: unparsedAttrs.Date || '', 
                Seller: unparsedAttrs.Seller || '',   
                Lot: unparsedAttrs.Lot || '',     
            }
            resolve([
                parsedAttrs.PO_ID.toString(),
                parsedAttrs.Buyer.toString(),
                parsedAttrs.Product.toString(),
                parsedAttrs.Num_Product.toString(),
                parsedAttrs.Price.toString(),
                parsedAttrs.Date.toString(),
                parsedAttrs.Seller.toString(),
                parsedAttrs.Lot.toString(),
            ])
        } catch (e) {
            logger.error(`${functionName} Parsing attributes failed ${e}`);
            reject(`Sorry could not parse attributes: ${e}`);
        }

    });
}

function ParseCreateInvoice(unparsedAttrs) { // for transfer 
    let functionName = '[toBC.CreateInvoice(unparsedAttrs)]';

    return new Promise((resolve, reject) => {
        
        let parsedAttrs = {};
        //new kvs().putStore(inv_identity,unparsedAttrs)
        
        try {
            parsedAttrs = {
                ID_Invoice: unparsedAttrs.ID_Invoice || '',
                PO_ID: unparsedAttrs.PO_ID || '',
                Received_date: unparsedAttrs.Received_date || '', 
                NumSent: unparsedAttrs.NumSent || '', 
                Installment_Price: unparsedAttrs.Installment_Price || '', 
                Seller : unparsedAttrs.Seller || '',
                // Product: unparsedAttrs.Product || '',
                // Price: unparsedAttrs.Price || '',
                // Buyer: unparsedAttrs.Buyer || '',    
            }
            resolve([
                parsedAttrs.ID_Invoice.toString(),
                parsedAttrs.PO_ID.toString(),
                parsedAttrs.Received_date.toString(),
                parsedAttrs.NumSent.toString(),
                parsedAttrs.Installment_Price.toString(),
                parsedAttrs.Seller.toString(),
                // parsedAttrs.Product.toString(),
                // parsedAttrs.Price.toString(),
               
                // parsedAttrs.Buyer.toString(),
            ])
        } catch (e) {
            logger.error(`${functionName} Parsing attributes failed ${e}`);
            reject(`Sorry could not parse attributes: ${e}`);
        }

    });
}
function ParseCheckPO(unparsedAttrs) { //for cheak CheckBalance
    let functionName = '[toBC.ParseCheckPO(unparsedAttrs)]';

    return new Promise((resolve, reject) => {
        
        let parsedAttrs = {};
        //new kvs().putStore(inv_identity,unparsedAttrs)
        
        try {
            parsedAttrs = { //รับมาจาก json
                PO_ID: unparsedAttrs.PO_ID || '',
                Buyer: unparsedAttrs.Buyer || '',
            }
            resolve([
                parsedAttrs.PO_ID.toString(),
                parsedAttrs.Buyer.toString(),
            ])
        } catch (e) {
            logger.error(`${functionName} Parsing attributes failed ${e}`);
            reject(`Sorry could not parse attributes: ${e}`);
        }

    });
}
function ParseCheckInvoice(unparsedAttrs) { //for cheak CheckBalance
    let functionName = '[toBC.ParseCheckInvoice(unparsedAttrs)]';

    return new Promise((resolve, reject) => {
        
        let parsedAttrs = {};
        //new kvs().putStore(inv_identity,unparsedAttrs)
        
        try {
            parsedAttrs = { //รับมาจาก json
                INVOICE_ID: unparsedAttrs.INVOICE_ID || '',
                Seller: unparsedAttrs.Seller || '',
            }
            resolve([
                parsedAttrs.INVOICE_ID.toString(),
                parsedAttrs.Seller.toString(),
            ])
        } catch (e) {
            logger.error(`${functionName} Parsing attributes failed ${e}`);
            reject(`Sorry could not parse attributes: ${e}`);
        }

    });
}
function ParseCheckUser(unparsedAttrs) { //for cheak CheckBalance
    let functionName = '[toBC.ParseCheckUser(unparsedAttrs)]';

    return new Promise((resolve, reject) => {
        
        let parsedAttrs = {};
        //new kvs().putStore(inv_identity,unparsedAttrs)
        
        try {
            parsedAttrs = { //รับมาจาก json
                User: unparsedAttrs.User || '',
            }
            resolve([
                parsedAttrs.User.toString(),
            ])
        } catch (e) {
            logger.error(`${functionName} Parsing attributes failed ${e}`);
            reject(`Sorry could not parse attributes: ${e}`);
        }

    });
}

/**
 * Creates a new ServiceRequest object.
 * @class
 */
class toBC {

    /**
     * Represents a toBC.
     * @constructs toBC
     * @param {string} userName - Enrollment Id of the blockchain user
     */
    constructor(userName) {
        this.enrollID = userName;
    }

   
    /**
     * Create new serviceRequest.
     * @method
     * @param {object} unparsedAttrs - New ServiceRequest Object
     */

    CreatePO(unparsedAttrs) {
        let self = this;
        let functionName = '[toBC.CreatePO(unparsedAttrs)]';
       // self.uUID = UUID.generateUUID_RFC4122();

        return new Promise((resolve, reject) => {

            let invokeObject = {};

            ParseCreatePO(unparsedAttrs).then((parsedAttrs) => {
                // console.log('parsedAttrs:' + parsedAttrs);
                invokeObject = {
                    enrollID: self.enrollID,
                    fcnname: CreatePO,
                    attrs: parsedAttrs
                };
                blockchain.invoke(invokeObject.enrollID, invokeObject.fcnname, invokeObject.attrs, INVOKE_ATTRIBUTES).then((result) => {
                    let resultParsed = result.toString();
                    logger.debug(resultParsed);
                    resolve({
                        message: {
                            PO_ID: parsedAttrs[0],
                            Buyer: parsedAttrs[1],
                            Product: parsedAttrs[2],
                            Num_Product: parsedAttrs[3], 
                            Price: parsedAttrs[4], 
                            Date: parsedAttrs[5], 
                            Seller: parsedAttrs[6], 
                            Lot: parsedAttrs[7], 
                        }
                     });
                }).catch((e) => {
                    logger.error(`${functionName}  ${e}`);
                    reject(` ${e}`);
                });
            }).catch((e) => {
                logger.error(`${functionName} Failed to create new ServiceRequest (createServiceRequest() function failed): ${JSON.stringify(e)}`);
                reject(`Failed to create new ServiceRequest (createServiceRequest() function failed): ${e}`);
            });
        });
    }

    CreateInvoice(unparsedAttrs) {
        let self = this;
        let functionName = '[toBC.CreateInvoice(unparsedAttrs)]';
       // self.uUID = UUID.generateUUID_RFC4122();

        return new Promise((resolve, reject) => {

            let invokeObject = {};

            ParseCreateInvoice(unparsedAttrs).then((parsedAttrs) => {
                // console.log('parsedAttrs:' + parsedAttrs);
                invokeObject = {
                    enrollID: self.enrollID,
                    fcnname: CreateInvoice,
                    attrs: parsedAttrs
                };
                // console.log(parsedAttrs.User+"+++++++++++++++++++++++++++++++++++++++++++++++++++++")
                // console.log(invokeObject.enrollID+"+++++++++++++++++++++++++++++++++++++++++++++++++++++")
                blockchain.invoke(invokeObject.enrollID, invokeObject.fcnname, invokeObject.attrs, INVOKE_ATTRIBUTES).then((result) => {
                    let resultParsed = result.toString();
                    logger.debug(resultParsed);
                    resolve({
                        message: {
                            ID_Invoice: parsedAttrs[0],
                            PO_ID: parsedAttrs[1], 
                            // Product: parsedAttrs[2],
                            // Price: parsedAttrs[3], 
                            Received_date: parsedAttrs[2], 
                            NumSent: parsedAttrs[3], 
                            Installment_Price: parsedAttrs[4], 
                            Seller: parsedAttrs[5],
                            // Buyer: parsedAttrs[6], 
                        }
                     });
                }).catch((e) => {
                    logger.error(`${functionName}  ${e}`);
                    reject(` ${e}`);
                });
            }).catch((e) => {
                logger.error(`${functionName} Failed to create new ServiceRequest (createServiceRequest() function failed): ${JSON.stringify(e)}`);
                reject(`Failed to create new ServiceRequest (createServiceRequest() function failed): ${e}`);
            });
        });
    }
    CheckPO(unparsedAttrs) {
        let self = this;
        let functionName = '[toBC.ParseCheckPO(unparsedAttrs)]';
       // self.uUID = UUID.generateUUID_RFC4122();

        return new Promise((resolve, reject) => {

            let invokeObject = {};
            let data 
            ParseCheckPO(unparsedAttrs).then((parsedAttrs) => {
                // console.log('parsedAttrs:' + parsedAttrs);
                invokeObject = {
                    enrollID: self.enrollID,
                    fcnname: CHECKPO,
                    attrs: parsedAttrs
                };
                
                blockchain.query(invokeObject.enrollID, invokeObject.fcnname, invokeObject.attrs, INVOKE_ATTRIBUTES).then((result) => {
                    let resultParsed = result.result.toString();
                    // console.log("00000000000000000000000000000000000000000000000toBC CheckPO ********************")
                    // // fs.readFile(file, 'utf8', function (err, resultParsed) {
                    // //     if (err) {
                    // //       console.log('Error: ' + err);
                    // //       return;
                    // //     }
                      
                    // //     data = JSON.parse(resultParsed);
                      
                    // //     console.dir(data+"55555555555555555555555555555555555555555");
                    // //   });
                    // //   console.dir(data+"55555555555555555555555555555555555555555");
                    // //   console.log(data+"55555555555555555555555555555555555555555");
                    // let bufferOriginal = Buffer.from(result.data);
                    // let StringUnicod = bufferOriginal.toString('utf8')
                    // console.log(StringUnicod+"555555555555555555555555555555");
                    // // var  money =parseInt(StringUnicod, 10);
                    // console.log(StringUnicod+"   in block number : --------------------------------------")
                    // console.log(resultParsed+"toBC CheckPO ********************")
                    // logger.debug(resultParsed);
                    resolve({
                        message: { //ค่าที่ ปริ้นออกมาจาก json
                            PO_ID: parsedAttrs[0],
                            Buyer: parsedAttrs[1],
                            PO : resultParsed,
                        }
                     });
                }).catch((e) => {
                    logger.error(`${functionName}  ${e}`);
                    reject(` ${e}`);
                });
            }).catch((e) => {
                logger.error(`${functionName} Failed to create new ServiceRequest (createServiceRequest() function failed): ${JSON.stringify(e)}`);
                reject(`Failed to create new ServiceRequest (createServiceRequest() function failed): ${e}`);
            });
        });
    }
    CheckInvoice(unparsedAttrs) {
        let self = this;
        let functionName = '[toBC.ParseCheckInvoice(unparsedAttrs)]';
       // self.uUID = UUID.generateUUID_RFC4122();

        return new Promise((resolve, reject) => {

            let invokeObject = {};
            let data 
            ParseCheckInvoice(unparsedAttrs).then((parsedAttrs) => {
                console.log('parsedAttrs:' + parsedAttrs);
                invokeObject = {
                    enrollID: self.enrollID,
                    fcnname: CHECKINVOICE,
                    attrs: parsedAttrs
                };
                
                blockchain.query(invokeObject.enrollID, invokeObject.fcnname, invokeObject.attrs, INVOKE_ATTRIBUTES).then((result) => {
                    let resultParsed = result.result.toString();
                    resolve({
                        message: { //ค่าที่ ปริ้นออกมาจาก json
                            INVOICE_ID: parsedAttrs[0],
                            Seller: parsedAttrs[1],
                            Invoice : resultParsed,
                        }
                     });
                }).catch((e) => {
                    logger.error(`${functionName}  ${e}`);
                    reject(` ${e}`);
                });
            }).catch((e) => {
                logger.error(`${functionName} Failed to create new ServiceRequest (createServiceRequest() function failed): ${JSON.stringify(e)}`);
                reject(`Failed to create new ServiceRequest (createServiceRequest() function failed): ${e}`);
            });
        });
    }

    CheckUser(unparsedAttrs) {
        let self = this;
        let functionName = '[toBC.ParseCheckUser(unparsedAttrs)]';
       // self.uUID = UUID.generateUUID_RFC4122();

        return new Promise((resolve, reject) => {

            let invokeObject = {};
            let data 
            ParseCheckUser(unparsedAttrs).then((parsedAttrs) => {
                console.log('parsedAttrs:' + parsedAttrs);
                invokeObject = {
                    enrollID: self.enrollID,
                    fcnname: CheckUser,
                    attrs: parsedAttrs
                };
                
                blockchain.query(invokeObject.enrollID, invokeObject.fcnname, invokeObject.attrs, INVOKE_ATTRIBUTES).then((result) => {
                    let resultParsed = result.result.toString();
                    resolve({
                        message: { //ค่าที่ ปริ้นออกมาจาก json
                            User: parsedAttrs[0],
                            History : resultParsed,
                        }
                     });
                }).catch((e) => {
                    logger.error(`${functionName}  ${e}`);
                    reject(` ${e}`);
                });
            }).catch((e) => {
                logger.error(`${functionName} Failed to create new ServiceRequest (createServiceRequest() function failed): ${JSON.stringify(e)}`);
                reject(`Failed to create new ServiceRequest (createServiceRequest() function failed): ${e}`);
            });
        });
    }

    
}

module.exports = toBC;