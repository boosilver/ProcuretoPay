package main

import (
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type FundTransferChaincode struct {
}
type USER_INFORMATION struct {
	USER_ID      string
	USER_HISTORY []string //IN STRING IS PO DATA
}
type STR_PO struct {
	PO_ID       string
	BUYER   string
	PRODUCT string
	PRICE   string
	DATE    string
	SELLER  string
	Num_Product	string
	Lot	string
	ALL_INVOICE []string
}
type STR_INVOICE struct {
	INVOICE_ID string
	PO_ID      string
	SELLER     string
	NumSent	   string
	Installment_Price	string
	RECEIVED_DAY string
	PRODUCT    string
	PRICE      string
	All_products	string
	All_prices		string
	Num			string
	STR_PO       STR_PO
	// BUYER        string
	// PRODUCT      string
	// PRICE        string
}

var line = ("-------------------------------------------------------------------------------")
var linePO = ("----------------------------   PURCHASE ORDER   -----------------------------")
var lineIvoice = ("----------------------------   INVOICE   ------------------------------------")

func (t *FundTransferChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {
	return shim.Success(nil)
}
func (t *FundTransferChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	if function == "createPO" {
		return t.CreatePO(stub, args)
	} else if function == "CheckUser" {
		return t.CheckUser(stub, args)
	} else if function == "createInvoice" {
		return t.CreateINVOICE(stub, args)
	} else if function == "CHECKPO" {
		return t.CheckPO(stub, args)
	} else if function == "CHECKINVOICE" {
		return t.CheckINVOICE(stub, args)
	}
	return shim.Error("Invalid invoke function name. ")
}

func (t *FundTransferChaincode) CreatePO(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var PO_ID string
	var BUYER string
	var PRODUCT string
	var PRICE string
	var DATE string
	var SELLER string
	var Num_Product string
	var Lot string
	var err error
	if len(args) != 8 {
		return shim.Error("Incorrect number of arguments. ")
	}
	History := USER_INFORMATION{}
	PO_ID = args[0]
	BUYER = args[1]
	PRODUCT = args[2]
	Num_Product = args[3]
	PRICE = args[4]
	DATE = args[5]
	SELLER = args[6]
	Lot = args[7]
	returntoeven := linePO + "\nPO_ID = " + PO_ID + "\n" + "BUYER = " + BUYER + "\n" + "PRODUCT = " + PRODUCT + "\n" +"NUM_PRODUCT = " + Num_Product + "\n"+"PRICE = "+PRICE+"\n"+"DATE = " + DATE + "\n" + "SELLER = " + SELLER + "\n"+"Lot = "+Lot +"\n"+ line
	creat_PO, err := stub.GetState(PO_ID)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	if creat_PO != nil {
		return shim.Error("PO havn't value ")
	}
	PO_DATA := STR_PO{
					PO_ID:		PO_ID,
					BUYER: 		BUYER,
					PRODUCT:	PRODUCT,
					PRICE:		PRICE,
					DATE:		DATE,
					SELLER:		SELLER,
					Num_Product:	Num_Product,
					Lot:		Lot,
				}
	PO_MARSHAL, err := json.Marshal(PO_DATA)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't Marshal creat PO")
	}
	if PO_MARSHAL == nil {
		return shim.Error("Marshal havn't value")
	}
	err = stub.PutState(PO_ID, PO_MARSHAL)
	if err != nil {
		fmt.Print("err")
		return shim.Error("can't put stub ")
	}
	fmt.Println(linePO)
	fmt.Println("PO_ID = " + PO_ID + "\n" + "BUYER = " + BUYER + "\n" + "PRODUCT = " + PRODUCT + "\n" + Num_Product + "\n"+"PRICE = "+PRICE+"\n"+ "DATE = " + DATE + "\n" + "SELLER = " + SELLER+"\n"+"Lot = "+Lot +"\n")
	fmt.Println(line)
	Payload := []byte(returntoeven)
	stub.SetEvent("event", Payload)
	//////////////
	IMFORMATION_USER, err := stub.GetState(BUYER)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	json.Unmarshal(IMFORMATION_USER, &History)
	NEW_HISTORY := History.USER_HISTORY
	NEW_HISTORY = append(NEW_HISTORY, PO_ID) //OR INVOICE_ID
	USER_ID:=BUYER
	var FINAL_HISTORY = USER_INFORMATION{
		USER_ID:      USER_ID,
		USER_HISTORY: NEW_HISTORY,
	}
	HISTORY_MARSHAL, err := json.Marshal(FINAL_HISTORY)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't Marshal creat FINAL_HISTORY")
	}

	err = stub.PutState(USER_ID, HISTORY_MARSHAL)
	if err != nil {
		fmt.Print("err")
		return shim.Error("can't put stub ")
	}
	return shim.Success(nil)
}
var Num_Invoice string
func (t *FundTransferChaincode) CreateINVOICE(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var INVOICE_ID string
	var INVOICE_Old string
	var SELLER string
	var NumSent string
	var Installment_Price string
	var All_products string
	var All_prices string
	var InvoiceKey string
	var NumI int
	var RECEIVED_DAY string
	var PO_ID string
	PO_DATA := STR_PO{}
	EACH_INVOICE :=STR_INVOICE{}
	if len(args) != 6 {
		return shim.Error("Incorrect number of arguments. ")
	}
	History := USER_INFORMATION{}
	INVOICE_ID = args[0]
	PO_ID = args[1]
	RECEIVED_DAY = args[2]
	NumSent = args[3]///
	Installment_Price = args[4] 
	SELLER = args[5]
	All_products = NumSent
	All_prices = Installment_Price
	Invoices_leaves := SELLER+"$$$"+PO_ID
	InvoiceK :=INVOICE_ID+"$$$"+PO_ID
	chackInvoiceKey, err := stub.GetState(InvoiceK)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	if chackInvoiceKey != nil {
		return shim.Error("THIS INVOICE HAS NUMBER ")
	}
	creat_Invoice, err := stub.GetState(Invoices_leaves)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	if creat_Invoice == nil{
		err = stub.PutState(Invoices_leaves, []byte(strconv.Itoa(1)))
			if err != nil {
			return shim.Error("Expecting integer value for asset holding")
			}
	}else{
		i:= 1
		num, err := strconv.Atoi(string(creat_Invoice))
		if err != nil {
			return shim.Error("can't chang to int")
		}
		for ;num != i;i++{
			fmt.Println(i)
		}
		err = stub.PutState(Invoices_leaves, []byte(strconv.Itoa(i+1)))
			if err != nil {
			return shim.Error("Expecting integer value for asset holding")
			}
	}
	Num_Invoice, err := stub.GetState(Invoices_leaves)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't GetState")
	}
	
	// Num_I := string(Num_Invoice)
	var Num_I int
	if Num_Invoice != nil {
		Num_I,err = strconv.Atoi(string(Num_Invoice))
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't change string to int 1")
	}
	}
	
	Num_I = Num_I+1
	// Num_I := strconv.Itoa(N)
	check_PO, err := stub.GetState(PO_ID)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't GetState")
	}
	if check_PO == nil {
		return shim.Error("PO can't find ")
	}
	json.Unmarshal(check_PO, &PO_DATA)
	SELLER_FORMcreatePO := PO_DATA.SELLER
	if SELLER_FORMcreatePO != SELLER {
		return shim.Error("Error Seller not equal")
	}
	NEW_ALL_INVOICE := PO_DATA.ALL_INVOICE
	NEW_ALL_INVOICE = append(NEW_ALL_INVOICE, INVOICE_ID)
	NEW_PO_INFORMATION := STR_PO{
		PO_ID:       PO_DATA.PO_ID,
		BUYER:        PO_DATA.BUYER,
		DATE:        PO_DATA.DATE,
		PRODUCT:     PO_DATA.PRODUCT,
		PRICE:       PO_DATA.PRICE,
		SELLER:      PO_DATA.SELLER,
		Num_Product:	PO_DATA.Num_Product,
		Lot:		 PO_DATA.Lot,
		ALL_INVOICE: NEW_ALL_INVOICE,
	}
	PO_MARSHAL, err := json.Marshal(NEW_PO_INFORMATION)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't Marshal PO")
	}
	err = stub.PutState(PO_ID, PO_MARSHAL)
	if err != nil {
		fmt.Print("err")
		return shim.Error("can't put stub ")
	}



	// NumI_S := "1"
	InvoiceKey =INVOICE_ID+"$$$"+PO_ID
	// +"$$$"+NumI_S
	check_NumSent, err := stub.GetState(InvoiceKey)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't GetState")
	}
	NumI =1 
	for ;check_NumSent != nil;NumI++{
		InvoiceKey =INVOICE_ID+"$$$"+PO_ID
		// +"$$$"+strconv.Itoa(NumI)
		check_NumSent, err = stub.GetState(InvoiceKey)
		if err != nil {
			return shim.Error("Can't GetState check_NumSent")
		}
		// fmt.Print("///")
		// fmt.Println(check_NumSent)
		// fmt.Println(NumI)
	}
	NumI =NumI-2
	InvoiceKey =INVOICE_ID+"$$$"+PO_ID
	// +"$$$"+strconv.Itoa(NumI)


	check_PO, err = stub.GetState(PO_ID)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't GetState")
	}
	if check_PO == nil {
		return shim.Error("PO can't find ")
	}
	json.Unmarshal(check_PO, &PO_DATA)
	InvoiceKey2 := PO_DATA.ALL_INVOICE
	for i := 0; i < len(InvoiceKey2); i++ {
		INVOICE_Old = InvoiceKey2[i]+"$$$"+PO_ID
		fmt.Println(i)
		fmt.Println(INVOICE_Old)
		fmt.Println("--------------------")
		}

		InvoiceNum, err := stub.GetState(INVOICE_Old)
		if err != nil {
			fmt.Println(err)
			return shim.Error("Failed to get state")
		}
		json.Unmarshal(InvoiceNum, &EACH_INVOICE)
		All_products_C := EACH_INVOICE.All_products
		All_prices_C := EACH_INVOICE.All_prices
		// fmt.Println(PRODUCT_INVOICE)
	



	// fmt.Println(InvoiceKey+"+++++++++++++++++")
	check_NumSent, err = stub.GetState(InvoiceKey)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't GetState check_NumSent2")
	}
	NumSent_data := STR_INVOICE{}
	json.Unmarshal(check_NumSent, &NumSent_data)
	All_productsO, err:=strconv.Atoi(All_products_C)
	// if err != nil {
	// 	fmt.Print(err)
	// 	return shim.Error("Can't change string to int2")
	// }
	All_productsN, err:=strconv.Atoi(All_products)
	// if err != nil {
	// 	fmt.Print(err)
	// 	return shim.Error("Can't change string to int3")
	// }
	All_productsSum:=All_productsN+All_productsO
	All_products = strconv.Itoa(All_productsSum)
	All_pricesO, err:=strconv.Atoi(string(All_prices_C))
	// if err != nil {
	// 	fmt.Print(err)
	// 	return shim.Error("Can't change string to int4")
	// }
	All_pricesN, err:=strconv.Atoi(string(All_prices))
	// if err != nil {
	// 	fmt.Print(err)
	// 	return shim.Error("Can't change string to int5")
	// }
	All_pricesSum :=All_pricesN+All_pricesO
	All_prices = strconv.Itoa(All_pricesSum)
	
	Num := strconv.Itoa(Num_I)
	NumFull, err := strconv.Atoi(Num)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't change string to int6")
	}
	LotFull, err := strconv.Atoi(PO_DATA.Lot)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't change string to int7")
	}
	if NumFull > LotFull {
		return shim.Error("The invoice is complete")
	}
	if Num == PO_DATA.Lot{
		if All_products != PO_DATA.Num_Product{
			All_productsFull, err := strconv.Atoi(All_products)
			if err != nil {
			return shim.Error("Can't change string to int8")
			}
			Num_ProductFull, err := strconv.Atoi(PO_DATA.Num_Product)
			if err != nil {
			return shim.Error("Can't change string to int9")
			}
			Result:= Num_ProductFull-All_productsFull
			ResultProduct:=strconv.Itoa(Result)
			return shim.Error("Product must full , Absent or over = "+ResultProduct)
		}else if All_prices != PO_DATA.PRICE{
			All_pricesFull, err := strconv.Atoi(All_prices)
			if err != nil {
			return shim.Error("Can't change string to int10")
			}
			PriceFull, err := strconv.Atoi(PO_DATA.PRICE)
			if err != nil {
			return shim.Error("Can't change string to int11")
			}
			Result:= PriceFull-All_pricesFull
			ResultProduct:=strconv.Itoa(Result)
			return shim.Error("Price must full, Absent or over = "+ResultProduct)
		}
		
	}
	

	var STR_INVOICE = STR_INVOICE{
		INVOICE_ID:   INVOICE_ID,
		PO_ID:        PO_ID,
		RECEIVED_DAY: RECEIVED_DAY,
		SELLER:       SELLER,
		NumSent:	  NumSent,
		Installment_Price:	Installment_Price,
		All_products:	All_products,
		All_prices:		All_prices,
		Num:		  Num,
		STR_PO:       PO_DATA,
	}
	
	// INVOICE_DATA := STR_INVOICE{INVOICE_ID, PO_ID, SELLER, RECEIVED_DAY}
	INVOICE_MARSHAL, err := json.Marshal(STR_INVOICE)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't Marshal creat INVOICE")
	}
	if INVOICE_MARSHAL == nil {
		return shim.Error("Marshal havn't value")
	}
	
	InvoiceKey=INVOICE_ID+"$$$"+PO_ID
	// +"$$$"+Num

	fmt.Println(InvoiceKey+"   keyyyyyyyyyy")
	err = stub.PutState(InvoiceKey, INVOICE_MARSHAL)
	if err != nil {
		fmt.Print("err")
		return shim.Error("can't put stub ")
	}
	fmt.Println(lineIvoice)
	fmt.Println("INVOICE_ID = " + INVOICE_ID + "\n" + "SELLER = " + SELLER + "\n" + "PRODUCT = " + PO_DATA.PRODUCT +"\n"+ "PRICE = " + PO_DATA.PRICE + "\n" + "RECEIVED_DAY = " + RECEIVED_DAY + "\n" + "PO_ID =  " + PO_ID + "\n" + "BUYER = " + PO_DATA.BUYER + "\n" +"NumSent = " + NumSent + "\n" +"Installment_Price = " + Installment_Price + "\n" +"All_products = "+All_products+"\n"+"All_prices = "+All_prices+"\n"+"Num_Invoice = "+ Num)
	fmt.Println(line)
	returntoeven := lineIvoice + "\nINVOICE_ID = " + INVOICE_ID + "\n" + "SELLER = " + SELLER + "\n" + "PRODUCT = " + PO_DATA.PRODUCT +"\n"+ "PRICE = " + PO_DATA.PRICE + "\n" + "RECEIVED_DAY = " + RECEIVED_DAY + "\n" + "PO_ID =  " + PO_ID + "\n" + "BUYER = " + PO_DATA.BUYER + "\n" +"NumSent = " + NumSent + "\n" +"Installment_Price = " + Installment_Price + "\n" +"All_products = "+All_products+"\n"+"All_prices = "+All_prices+"\n"+ "Num_Invoice = "+ Num + "\n" + line
	Payload := []byte(returntoeven)
	stub.SetEvent("event", Payload)
	/////////////////////////////
	IMFORMATION_USER, err := stub.GetState(SELLER)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	json.Unmarshal(IMFORMATION_USER, &History)
	NEW_HISTORY := History.USER_HISTORY
	NEW_HISTORY = append(NEW_HISTORY, INVOICE_ID) //OR INVOICE_ID
	USER_ID := SELLER
	var FINAL_HISTORY = USER_INFORMATION{
		USER_ID:      USER_ID,
		USER_HISTORY: NEW_HISTORY,
	}
	HISTORY_MARSHAL, err := json.Marshal(FINAL_HISTORY)
	if err != nil {
		fmt.Print(err)
		return shim.Error("Can't Marshal creat FINAL_HISTORY")
	}

	err = stub.PutState(USER_ID, HISTORY_MARSHAL)
	if err != nil {
		fmt.Print("err")
		return shim.Error("can't put stub ")
	}
	return shim.Success(nil)
}

func (t *FundTransferChaincode) CheckPO(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var PO_ID string
	var BUYER string
	PO_MARSHAL := STR_PO{}
	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting name of the person to query")
	}
	PO_ID = args[0]
	BUYER = args[1]
	// Userkey := wallet + "$$$" + User
	// Get the state from the ledger
	PO_DATA, err := stub.GetState(PO_ID)
	if err != nil {
		return shim.Error("can't getstate")
	}
	if PO_DATA == nil {
		return shim.Error("Po data nil")
	}
	json.Unmarshal(PO_DATA, &PO_MARSHAL)
	CHECK_BUYER := PO_MARSHAL.BUYER
	if BUYER != CHECK_BUYER {
		return shim.Error("Error Buyer not equal")
	}

	jsonResp := "{\"PO_ID\":\"" + PO_ID + "\",\"\nPURCHASE ORDER\":\"" + string(PO_DATA) + "\"}"
	fmt.Printf("Query Response:%s\n", jsonResp)
	return shim.Success(PO_DATA)
}
func (t *FundTransferChaincode) CheckINVOICE(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var INVOICE_ID string
	var InvoiceKey string
	var SELLER string
	InvoiceKey =INVOICE_ID+"$$$"+"2"
	INVOICE_MARSHAL := STR_INVOICE{}
	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting name of the person to query")
	}
	INVOICE_ID = args[0]
	SELLER = args[1]
	INVOICE_DATA, err := stub.GetState(InvoiceKey)
	if err != nil {
		// jsonResp := "{\"Error\":\"Failed to get state for PO_ID " + INVOICE_ID + "\"}"
		return shim.Error("get invoice error")
	}

	if INVOICE_DATA == nil {
		// jsonResp := "{\"Error\":\"Nil Value for PO_ID " + INVOICE_ID + "\"}"
		// fmt.Printf("Entity not found")
		return shim.Error("***********------------******************")
	}
	json.Unmarshal(INVOICE_DATA, &INVOICE_MARSHAL)
	CHECK_SELLER := INVOICE_MARSHAL.SELLER
	if SELLER != CHECK_SELLER {
		return shim.Error("Error Seller not equal")
	}

	jsonResp := "{\"INVOICE_ID\":\"" + INVOICE_ID + "\",\"\nINVOICE \":\"" + string(INVOICE_DATA) + "\"}"
	fmt.Printf("Query Response:%s\n", jsonResp)
	return shim.Success(INVOICE_DATA)
}
func (t *FundTransferChaincode) CheckUser(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var User string
	var err error
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. ")
	}
	HISTORY_UNMARSHAL := USER_INFORMATION{}
	User = args[0]
	IMFORMATION_USER, err := stub.GetState(User)
	if err != nil {
		fmt.Println(err)
		return shim.Error("Failed to get state")
	}
	if IMFORMATION_USER == nil {
		return shim.Error("Don't have history of User ")
	}
	json.Unmarshal(IMFORMATION_USER, &HISTORY_UNMARSHAL)
	HISTORY := HISTORY_UNMARSHAL.USER_HISTORY
	for i := 0; i < len(HISTORY); i++ {
		show_data := HISTORY[i]
		fmt.Println(show_data)
	}
	return shim.Success(IMFORMATION_USER)
}

func main() {
	err := shim.Start(new(FundTransferChaincode))
	if err != nil {
		fmt.Printf("Error starting FundTransfer chaincode: %s", err)
	}
}
